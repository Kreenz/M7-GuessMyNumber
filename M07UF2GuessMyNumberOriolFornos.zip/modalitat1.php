<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modalitat 1</title>
    <link rel="stylesheet" href="css/style-shortcuts.css">
</head>
<body class="flex-column center">

    <div class="flex-column center">
        <form class="flex-column center" name="range" action="/modalitat1.php" method="POST">
            <div class="box blue"></div>
            <div class="box yellow"></div>
            <div class="box pink"></div>
            <div class="box mash"></div>

            <div class="flex-row center tipus">
                <button type="submit" name="dificultat" value=10>RANG: 1 - 10</button>
                <button type="submit" name="dificultat" value=50>RANG: 1 - 50</button>
                <button type="submit" name="dificultat" value=100>RANG: 1 - 100</button>
            </div>

            <div class="flex-column center text">
                <?php
                    if (session_status() != PHP_SESSION_ACTIVE) session_start();
                    if(isset($_SESSION["mode"])){
                        $status = "No has entrat per el lloc que toca!";
                        $call = "No has entrar per el lloc que toca!";
                    } else {
                        if(isset($_POST["rang"])){
                            if($_POST["rang"] == "!") {
                                if(!empty($_SESSION["max"])){
                                    unset($_SESSION["max"]);
                                    updateResults(false);
                                }
                            }
                        }
                        $status = "No hi ha un rang iniciat.";
                        $call = (empty($_SESSION["max"])) ? "Selecciona un rang per començar el joc." : "El rang seleccionat es: 1 - " . $_SESSION["rang"] . ".";


                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            if(!empty($_SESSION["max"])){
                                $userPost = "";
                                if(isset($_POST["rang"])){
                                    $userPost = $_POST["rang"];
                                } else {
                                    $userPost = false;
                                }
                                
                                if(isset($_POST["dificultat"])){
                                    $status = "Ja hi ha un numero iniciat.";
                                } else {
                                    guessType($userPost);
                                    if(isset($_SESSION["max"])) $status = "El numero secret es " . $_SESSION["val"];
                                    else $status = "El numero secret es aquest SI o SI " . $_SESSION["val"];
                                }
                                
                            } else {
                                $_SESSION["min"] = 1;
                                if(isset($_POST["dificultat"])) {
                                    $_SESSION["max"] = intval($_POST["dificultat"]);
                                    $_SESSION["rang"] = intval($_POST["dificultat"]);

                                    guessType(false);
                                    $call = "Acabas d'inicar el joc! El rang seleccionat es: 1 - " . $_SESSION["rang"];
                                    $status = "El numero secret es " . $_SESSION["val"];
                                }
                            }
                        }
                    }

                    

                    function guessType($operator){
                        if(!$operator){
                            $_SESSION["val"] = guessNumber($_SESSION["min"], $_SESSION["max"]);
                        } else {
                            if($operator == "+"){
                                $_SESSION["min"] = $_SESSION["val"];
                                if(guessNumber($_SESSION["min"], $_SESSION["max"]) == $_SESSION["val"]) {
                                    $_SESSION["val"] = $_SESSION["min"] + 1;
                                    unset($_SESSION["max"]);
                                    updateResults(true);
                                }
                                else $_SESSION["val"] = guessNumber($_SESSION["min"], $_SESSION["max"]); 
                                
                            } elseif($operator == "-") {
                                $_SESSION["max"] = $_SESSION["val"]; 
                                $_SESSION["val"] = guessNumber($_SESSION["min"], $_SESSION["max"]);
                            } else {
                                unset($_SESSION["max"]);
                                updateResults(true);
                            }

                            if(!empty($_SESSION["max"])) {
                                if($_SESSION["val"] == $_SESSION["max"] && $_SESSION["val"] == $_SESSION["min"]) unset($_SESSION["max"]);   
                            }
                        }
                    }

                    function guessNumber($min, $max){
                        return floor((($max - $min) / 2) + $min);
                    }

                    function updateResults($win){
                        if($win){
                            $_SESSION["mode1-win"] = (empty($_SESSION["mode1-win"])) ? $_SESSION["mode1-win"]++ : 1;
                        }
                        $_SESSION["mode1-try"] = (empty($_SESSION["mode1-try"])) ? $_SESSION["mode1-try"]++ : 1;
                        $_SESSION["mode1-" . $_SESSION["rang"]] = (empty($_SESSION["mode1-" . $_SESSION["rang"]])) ? $_SESSION["mode1-" . $_SESSION["rang"]]++ : 1;
                    }
                ?>

                <div><?php echo $status; ?></div>
                <div><?php echo $call; ?></div>
            </div>
            <button type="submit" name="rang" value="+">ES MAJOR</button>
            <button type="submit" name="rang" value="-">ES MENOR</button>
            <button type="submit" name="rang" value="=">ES EL NUMERO</button>
            <button type="submit" name="rang" value="!">ABANDONAR</button>
        </form>

    </div>
</body>
</html>