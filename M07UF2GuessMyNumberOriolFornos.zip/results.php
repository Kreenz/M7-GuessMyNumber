<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultats</title>
    <link rel="stylesheet" href="css/style-shortcuts.css">
</head>
<body class="flex-column center">
    <div class="text2 flex-column center">
        <h4>Modalitat 1</h4>
        <div>
            <?php
                if (session_status() != PHP_SESSION_ACTIVE) session_start();
                if(empty($_SESSION["mode1-try"])) echo "Intents: 0 <br>";
                else echo "Intents: " . $_SESSION["mode1-try"] . "<br>";

                if(empty($_SESSION["mode1-win"])) echo "Victorias: 0 <br>";
                else echo "Victorias: " . $_SESSION["mode1-win"] . "<br>";
                
                if(empty($_SESSION["mode1-10"])) echo "Partidas jugades en el rang de 10: 0 <br>";
                else echo "Partidas jugades en el rang de 10: " . $_SESSION["mode1-10"] . "<br>";
                
                if(empty($_SESSION["mode1-50"])) echo "Partidas jugades en el rang de 50: 0 <br>";
                else echo "Partidas jugades en el rang de 50: " . $_SESSION["mode1-50"] . "<br>";

                if(empty($_SESSION["mode1-100"])) echo "Partidas jugades en el rang de 100: 0 <br>";
                else echo "Partidas jugades en el rang de 100: " . $_SESSION["mode1-100"] . "<br>";
            ?>
        </div>
    </div>
    <div class="text flex-column center">
        <h4>Modalitat 2</h4>
        <div>
            <?php
                if(empty($_SESSION["mode2-try"])) echo "Intents: 0 <br>";
                else echo "Intents: " . $_SESSION["mode2-try"] . "<br>";

                if(empty($_SESSION["mode2-win"])) echo "Victorias: 0 <br>";
                else echo "Victorias: " . $_SESSION["mode2-win"] . "<br>";
            ?>
        </div>
    </div>
</body>
</html>